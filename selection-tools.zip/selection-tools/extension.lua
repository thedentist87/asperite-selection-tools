-- Enhanced Selection Tools for Aseprite (GLOBAL + JSON persistence)
-- Keeps existing functionality, but selections are now global (not per sprite)
-- and persisted to a JSON file so they can be restored across sessions.

local lastSelectionRect = nil
local savedSelections = {} -- global array of {name=..., rect=Rectangle}

-- ===== JSON persistence helpers =====

local function escapeJsonString(s)
  return (tostring(s)
    :gsub("\\", "\\\\")
    :gsub("\"", "\\\"")
    :gsub("\b", "\\b")
    :gsub("\f", "\\f")
    :gsub("\n", "\\n")
    :gsub("\r", "\\r")
    :gsub("\t", "\\t"))
end

local function unescapeJsonString(s)
  -- minimal unescape for the sequences we produce
  return (tostring(s)
    :gsub("\\\"", "\"")
    :gsub("\\\\", "\\")
    :gsub("\\b", "\b")
    :gsub("\\f", "\f")
    :gsub("\\n", "\n")
    :gsub("\\r", "\r")
    :gsub("\\t", "\t"))
end

local function encodeSelectionsToJson(list)
  local parts = {"["}
  for i, item in ipairs(list) do
    local r = item.rect
    local name = escapeJsonString(item.name or ("Selection " .. tostring(i)))
    local one = string.format(
      "{\"name\":\"%s\",\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d}",
      name, r.x, r.y, r.width, r.height
    )
    parts[#parts+1] = one
    if i < #list then parts[#parts+1] = "," end
  end
  parts[#parts+1] = "]"
  return table.concat(parts)
end

-- ===== Canvas helpers =====

local function ceilToMultiple(n, m)
  if m <= 0 then return n end
  return math.ceil(n / m) * m
end

local function roundToMultiple(n, m, mode)
  if m <= 0 then return n end
  if mode == "Up" then
    return math.ceil(n / m) * m
  elseif mode == "Nearest" then
    return math.floor((n + m/2) / m) * m
  else
    return n
  end
end

function ResizeCanvasToMultiple()
  local spr = app.activeSprite
  if not spr then
    app.alert("No active sprite.")
    return
  end

  local dlg = Dialog("Resize Canvas to Multiple")
  dlg:number{ id="m", label="Multiple:", text="4", focus=true }
  dlg:combobox{ id="mode", label="Mode:", options={"Up", "Nearest"}, option="Up" }
  dlg:button{ id="ok", text="Resize" }
  dlg:button{ id="cancel", text="Cancel" }
  dlg:show{ wait=true }
  local d = dlg.data
  if not d.ok then return end

  local m = math.max(1, math.floor(d.m or 1))
  local mode = d.mode
  local w, h = spr.width, spr.height

  local newW = roundToMultiple(w, m, mode)
  local newH = roundToMultiple(h, m, mode)

  local diffW = newW - w
  local diffH = newH - h

  app.transaction(function()
    app.command.CanvasSize{
      ui=false,
      left=0, top=0,
      right=diffW, bottom=diffH
    }
  end)

  app.refresh()
end



local function decodeSelectionsFromJson(json)
  local list = {}
  if not json or json == "" then return list end
  -- very small, structure-specific JSON parser:
  -- looks for: {"name":"(…)","x":int,"y":int,"w":int,"h":int}
  for name, x, y, w, h in json:gmatch(
    "{\"name\"%s*:%s*\"(.-)\".-\"x\"%s*:%s*(-?%d+).-\"y\"%s*:%s*(-?%d+).-\"w\"%s*:%s*(-?%d+).-\"h\"%s*:%s*(-?%d+)"
  ) do
    local item = {
      name = unescapeJsonString(name),
      rect = Rectangle(tonumber(x), tonumber(y), tonumber(w), tonumber(h))
    }
    list[#list+1] = item
  end
  return list
end

local function getSavePath()
  -- Prefer Aseprite user config dir; fall back to current dir.
  local ok, p = pcall(function()
    if app.fs and app.fs.userConfigPath and app.fs.joinPath then
      return app.fs.joinPath(app.fs.userConfigPath, "aseprite_selections.json")
    end
    return "aseprite_selections.json"
  end)
  if ok and p then return p end
  return "aseprite_selections.json"
end

local function writeAllText(path, text)
  local f = io.open(path, "w")
  if not f then return false end
  f:write(text)
  f:close()
  return true
end

local function readAllText(path)
  local f = io.open(path, "r")
  if not f then return nil end
  local t = f:read("*a")
  f:close()
  return t
end

local SAVE_PATH = getSavePath()

local function saveToDisk()
  local ok, err = pcall(function()
    local json = encodeSelectionsToJson(savedSelections)
    writeAllText(SAVE_PATH, json)
  end)
  if not ok then
    app.alert("Could not save selections to JSON.\n" .. tostring(err))
  end
end

local function loadFromDisk()
  local ok, res = pcall(function()
    local json = readAllText(SAVE_PATH)
    if json then
      savedSelections = decodeSelectionsFromJson(json)
    else
      savedSelections = {}
    end
  end)
  if not ok then
    -- If decoding fails, start fresh but don't crash.
    savedSelections = {}
  end
end

local function deleteDiskSave()
  local ok = pcall(function()
    if app.fs and app.fs.isFile and app.fs.isFile(SAVE_PATH) then
      -- Overwrite with empty list instead of deleting to avoid permission issues
      writeAllText(SAVE_PATH, "[]")
    else
      -- Try to remove anyway as a fallback (may not exist)
      os.remove(SAVE_PATH)
    end
  end)
  return ok
end

-- ===== Utilities =====

local function rectToString(r)
  return string.format("x=%d y=%d w=%d h=%d", r.x, r.y, r.width, r.height)
end

local function findSelectionIndexByName(list, name)
  for i, item in ipairs(list) do
    if item.name == name then return i end
  end
  return nil
end

-- ===== Commands (global storage) =====

function SaveSelection()
    local spr = app.activeSprite
    if spr and not spr.selection.isEmpty then
        local b = spr.selection.bounds
        lastSelectionRect = Rectangle(b.x, b.y, b.width, b.height)

        local autoName = "Selection " .. tostring(#savedSelections + 1)
        table.insert(savedSelections, { name = autoName, rect = Rectangle(b.x, b.y, b.width, b.height) })
        saveToDisk()
        app.alert("Saved: " .. autoName .. " (" .. rectToString(b) .. ")")
    else
        app.alert("No selection to save.")
    end
end

function SaveNamedSelection()
    local spr = app.activeSprite
    if not spr then
        app.alert("No active sprite.")
        return
    end
    if spr.selection.isEmpty then
        app.alert("No selection to save.")
        return
    end

    local b = spr.selection.bounds

    local dlg = Dialog("Save Named Selection")
    dlg:entry{ id="name", label="Name:", text="Selection " .. tostring(#savedSelections + 1) }
    dlg:button{ id="ok", text="Save" }
    dlg:button{ id="cancel", text="Cancel" }
    dlg:show{ wait=true }
    local data = dlg.data
    if not data.ok then return end

    local name = data.name
    if name == "" then name = "Selection " .. tostring(#savedSelections + 1) end

    local idx = findSelectionIndexByName(savedSelections, name)
    if idx then
        savedSelections[idx] = { name = name, rect = Rectangle(b.x, b.y, b.width, b.height) }
        app.alert("Updated: " .. name)
    else
        table.insert(savedSelections, { name = name, rect = Rectangle(b.x, b.y, b.width, b.height) })
        app.alert("Saved: " .. name)
    end
    lastSelectionRect = Rectangle(b.x, b.y, b.width, b.height)
    saveToDisk()
end

function SaveEnteredSelection()
    local spr = app.activeSprite
    if not spr then
        app.alert("No active sprite.")
        return
    end

    app.tool = "rectangular_marquee"

    local dlg = Dialog("Enter Selection")
    dlg:number{ id="x", label="X:", text="0" }
    dlg:number{ id="y", label="Y:", text="0" }
    dlg:number{ id="w", label="Width:", text="32" }
    dlg:number{ id="h", label="Height:", text="32" }
    dlg:entry{ id="name", label="Name (opt):", text="Selection " .. tostring(#savedSelections + 1) }
    dlg:button{ id="ok", text="OK" }
    dlg:button{ id="cancel", text="Cancel" }
    dlg:show{ wait=true }

    local data = dlg.data
    if not data.ok then return end

    local rect = Rectangle(data.x, data.y, data.w, data.h)
    spr.selection:select(rect)
    lastSelectionRect = Rectangle(rect.x, rect.y, rect.width, rect.height)

    if data.name and data.name ~= "" then
        local idx = findSelectionIndexByName(savedSelections, data.name)
        if idx then
            savedSelections[idx] = { name = data.name, rect = Rectangle(rect.x, rect.y, rect.width, rect.height) }
            app.alert("Updated: " .. data.name)
        else
            table.insert(savedSelections, { name = data.name, rect = Rectangle(rect.x, rect.y, rect.width, rect.height) })
            app.alert("Saved: " .. data.name)
        end
        saveToDisk()
    end
    app.refresh()
end

function RestoreSelection()
    local spr = app.activeSprite
    if spr and lastSelectionRect then
        spr.selection:select(lastSelectionRect)
        app.refresh()
    else
        app.alert("No saved selection.")
    end
end

function ChooseAndRestoreSelection()
    local spr = app.activeSprite
    if not spr then
        app.alert("No active sprite.")
        return
    end
    if #savedSelections == 0 then
        app.alert("No named selections saved.")
        return
    end

    local names = {}
    for i, item in ipairs(savedSelections) do names[i] = item.name end

    local dlg = Dialog("Restore Selection")
    dlg:combobox{ id="name", label="Saved:", option=names[1], options=names }
    dlg:number{ id="dx", label="Offset X:", text="0" }
    dlg:number{ id="dy", label="Offset Y:", text="0" }
    dlg:number{ id="growW", label="+Width:", text="0" }
    dlg:number{ id="growH", label="+Height:", text="0" }
    dlg:button{ id="restore", text="Restore" }
    dlg:button{ id="delete", text="Delete" }
    dlg:button{ id="rename", text="Rename" }
    dlg:button{ id="cancel", text="Close" }
    dlg:show{ wait=true }
    local data = dlg.data
    if not data.restore and not data.delete and not data.rename then return end

    local chosen = data.name
    local idx = findSelectionIndexByName(savedSelections, chosen)
    if not idx then
        app.alert("Selection not found.")
        return
    end
    local item = savedSelections[idx]

    if data.delete then
        table.remove(savedSelections, idx)
        saveToDisk()
        app.alert("Deleted: " .. chosen)
        return
    elseif data.rename then
        local rd = Dialog("Rename Selection")
        rd:entry{ id="newname", label="New name:", text=chosen }
        rd:button{ id="ok", text="OK" }
        rd:button{ id="cancel", text="Cancel" }
        rd:show{ wait=true }
        local rdat = rd.data
        if rdat.ok and rdat.newname ~= "" then
            if findSelectionIndexByName(savedSelections, rdat.newname) and rdat.newname ~= chosen then
                app.alert("A selection with that name already exists.")
            else
                item.name = rdat.newname
                saveToDisk()
                app.alert("Renamed to: " .. rdat.newname)
            end
        end
        return
    else
        local nx = item.rect.x + (data.dx or 0)
        local ny = item.rect.y + (data.dy or 0)
        local nw = math.max(1, item.rect.width + (data.growW or 0))
        local nh = math.max(1, item.rect.height + (data.growH or 0))
        local rect = Rectangle(nx, ny, nw, nh)
        spr.selection:select(rect)
        lastSelectionRect = Rectangle(rect.x, rect.y, rect.width, rect.height)
        app.refresh()
    end
end

function ClearAllSavedSelections()
    savedSelections = {}
    deleteDiskSave()
    saveToDisk() -- ensure file contains []
    app.alert("Cleared all saved selections.")
end

-- ===== Plugin lifecycle =====

function init(plugin)
    -- Load any previously saved selections from disk
    loadFromDisk()

    local parentGroup = "edit_selectiontools"

    plugin:newMenuGroup{
        id = parentGroup,
        title = "Selection Tools",
        group = "edit_transform"
    }
    plugin:newCommand{
    id="ResizeCanvasToMultiple",
    title="Resize Canvas",
    group=parentGroup,
    onclick=ResizeCanvasToMultiple
    }


    plugin:newCommand{ id="SaveSelection", title="Save Selection (Quick)", group=parentGroup, onclick=SaveSelection }
    plugin:newCommand{ id="SaveNamedSelection", title="Save Selection As...", group=parentGroup, onclick=SaveNamedSelection }
    plugin:newCommand{ id="SaveEnteredSelection", title="Save Entered Selection", group=parentGroup, onclick=SaveEnteredSelection }
    plugin:newCommand{ id="ChooseAndRestoreSelection", title="Restore From Saved...", group=parentGroup, onclick=ChooseAndRestoreSelection }
    plugin:newCommand{ id="RestoreSelection", title="Restore Last Selection", group=parentGroup, onclick=RestoreSelection }
    plugin:newCommand{ id="ClearAllSavedSelections", title="Clear All Saved Selections", group=parentGroup, onclick=ClearAllSavedSelections }
end

function exit(plugin)
  -- Persist on exit just in case
  saveToDisk()
end
