# Selection Tools for Aseprite

Adds:
- Global saved selections (persisted to JSON -- Global)
- Restore, rename, delete selections
- Clear all saved selections
- Resize canvas to nearest multiple or up multiple X

## Install
1. Download this repo as a ZIP.
2. In Aseprite, go to **Edit → Preferences → Extensions → Add Extension**.
3. Select the ZIP file.
4. Enable the extension.

## Usage
Check the **Edit → Selection Tools** menu for commands.
